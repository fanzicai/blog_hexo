## hexo-theme-athene ##

### Athene 简介 ###
-  适用于[hexo](https://github.com/hexojs/hexo) 3.0及以上版本
-  参考了[hexo-theme-yilia](https://github.com/litten/hexo-theme-yilia)
-  为学习而建

### Athene 使用 ###
- 安装

    > 在 *%hexo根目录%* 执行  
    >  
    >`git clone https://github.com/fanzicai/hexo-theme-athene  themes/athene`

- 配置

    > 修改_config.yml文件
    > 
    > `theme: athene`
